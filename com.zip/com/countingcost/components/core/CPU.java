package com.countingcost.components.core;

public class CPU extends Core {
    public CPU(String nama, double price) {
        super(nama, price);
    }
}