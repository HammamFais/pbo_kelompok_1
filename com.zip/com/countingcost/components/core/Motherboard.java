package com.countingcost.components.core;

public class Motherboard extends Core {
    public Motherboard(String nama, double price) {
        super(nama, price);
    }
}