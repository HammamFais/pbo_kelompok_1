package com.countingcost.components.core;

import com.countingcost.components.Component;

public abstract class Core extends Component {
    public Core(String nama, double price) {
        super(nama, price);
    }
}