package com.countingcost.components.core;

public class RAM extends Core {
    public RAM(String nama, double price) {
        super(nama, price);
    }
}