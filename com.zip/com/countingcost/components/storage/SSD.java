package com.countingcost.components.storage;

public class SSD extends Storage {
    public SSD(String nama, double price) {
        super(nama, price);
    }
}