package com.countingcost.components.storage;

public class FlashDisk extends Storage {
    public FlashDisk(String nama, double price) {
        super(nama, price);
    }
}