package com.countingcost.components.storage;

public class CloudStorage extends Storage {
    public CloudStorage(String nama, double price) {
        super(nama, price);
    }
}