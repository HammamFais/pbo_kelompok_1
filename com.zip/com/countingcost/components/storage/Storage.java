package com.countingcost.components.storage;

import com.countingcost.components.Component;

public abstract class Storage  extends Component {
    public Storage (String nama, double price) {
        super(nama, price);
    }
}