package com.countingcost.components.peripheral;

public class Mouse extends Peripheral {
    public Mouse(String nama, double price) {
        super(nama, price);
    }
}