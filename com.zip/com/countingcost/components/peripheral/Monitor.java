package com.countingcost.components.peripheral;

public class Monitor extends Peripheral {
    public Monitor(String nama, double price) {
        super(nama, price);
    }
}