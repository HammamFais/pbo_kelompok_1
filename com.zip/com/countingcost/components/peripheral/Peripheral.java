package com.countingcost.components.peripheral;

import com.countingcost.components.Component;

public abstract class Peripheral extends Component {
    public Peripheral(String nama, double price) {
        super(nama, price);
    }
}