package com.countingcost.components.peripheral;

public class Keyboard extends Peripheral {
    public Keyboard(String nama, double price) {
        super(nama, price);
    }
}